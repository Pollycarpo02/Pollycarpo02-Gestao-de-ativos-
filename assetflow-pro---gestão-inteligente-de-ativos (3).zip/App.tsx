
import React, { useState, useEffect } from 'react';
import { storage } from './services/storage';
import { Asset, Department, CostCenter, Movement, AssetStatus } from './types';
import { Icons } from './constants';
import { Dashboard } from './components/Dashboard';
import { AssetList } from './components/AssetList';
import { AssetForm } from './components/AssetForm';
import { MovementList } from './components/MovementList';

enum View {
  DASHBOARD = 'dashboard',
  ASSETS = 'assets',
  MOVEMENTS = 'movements',
  SETTINGS = 'settings'
}

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.DASHBOARD);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | undefined>(undefined);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setAssets(storage.getAssets());
    setDepartments(storage.getDepartments());
    setCostCenters(storage.getCostCenters());
    setMovements(storage.getMovements());
  };

  const handleSaveAsset = (asset: Asset) => {
    // Registrar movimentação automática se for um novo ativo ou mudança de status
    const existing = assets.find(a => a.id === asset.id);
    if (!existing) {
      storage.addMovement({
        id: Date.now().toString(),
        assetId: asset.id,
        type: 'Entrada',
        date: new Date().toISOString(),
        description: `Cadastro inicial do ativo: ${asset.name}`,
        nfeKey: asset.nfeKey
      });
    } else if (existing.status !== asset.status) {
      storage.addMovement({
        id: Date.now().toString(),
        assetId: asset.id,
        type: 'Transferência',
        date: new Date().toISOString(),
        description: `Status alterado de ${existing.status} para ${asset.status}`,
        nfeKey: asset.nfeKey
      });
    }

    storage.saveAsset(asset);
    refreshData();
    setIsFormOpen(false);
    setEditingAsset(undefined);
  };

  const handleEditAsset = (asset: Asset) => {
    setEditingAsset(asset);
    setIsFormOpen(true);
  };

  const NavItem = ({ view, icon: Icon, label }: { view: View, icon: any, label: string }) => (
    <button
      onClick={() => setActiveView(view)}
      className={`flex items-center gap-3 w-full px-6 py-4 rounded-2xl transition-all ${
        activeView === view 
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-300' 
          : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700'
      }`}
    >
      <Icon />
      <span className="font-semibold text-sm">{label}</span>
    </button>
  );

  return (
    <div className="flex min-h-screen bg-slate-50 overflow-x-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-100 hidden lg:flex flex-col p-6 sticky top-0 h-screen z-30">
        <div className="flex items-center gap-3 px-2 mb-12">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-inner">
            A
          </div>
          <h1 className="font-bold text-xl tracking-tight text-slate-800 italic">AssetFlow<span className="text-blue-600 not-italic">Pro</span></h1>
        </div>

        <nav className="space-y-2 flex-1">
          <NavItem view={View.DASHBOARD} icon={Icons.Dashboard} label="Dashboard Geral" />
          <NavItem view={View.ASSETS} icon={Icons.Assets} label="Gestão de Ativos" />
          <NavItem view={View.MOVEMENTS} icon={Icons.Movements} label="Movimentações" />
          <NavItem view={View.SETTINGS} icon={Icons.Settings} label="Configurações" />
        </nav>

        <div className="mt-auto p-4 bg-slate-50 rounded-2xl border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">AD</div>
            <div>
              <p className="text-xs text-slate-500 font-medium leading-none">Administrador</p>
              <p className="text-sm font-bold text-slate-800">Unidade Matriz</p>
            </div>
          </div>
          <button className="w-full py-2 text-xs font-semibold text-red-400 hover:text-red-600 transition-colors text-left pl-11">Sair do Sistema</button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 lg:p-12 max-w-7xl mx-auto w-full">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <div className="text-blue-600 text-xs font-bold uppercase tracking-widest mb-1">Empresa Exemplo LTDA</div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">
              {activeView === View.DASHBOARD && "Painel Analítico"}
              {activeView === View.ASSETS && "Inventário Ativo"}
              {activeView === View.MOVEMENTS && "Logs de Ativos"}
              {activeView === View.SETTINGS && "Preferências"}
            </h2>
          </div>
          
          <div className="flex items-center gap-4">
             <button 
              onClick={() => { setEditingAsset(undefined); setIsFormOpen(true); }}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 active:scale-95 group"
            >
              <Icons.Plus />
              <span>Novo Registro</span>
            </button>
          </div>
        </header>

        <div className="relative">
          {activeView === View.DASHBOARD && <Dashboard assets={assets} />}
          
          {activeView === View.ASSETS && (
            <AssetList 
              assets={assets} 
              departments={departments} 
              costCenters={costCenters} 
              onEdit={handleEditAsset}
            />
          )}

          {activeView === View.MOVEMENTS && (
            <MovementList movements={movements} assets={assets} />
          )}

          {activeView === View.SETTINGS && (
            <div className="bg-white p-8 rounded-3xl border border-slate-100 animate-fadeIn">
              <h3 className="text-xl font-bold mb-6">Configurações de Estrutura</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-slate-600 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    Departamentos
                  </h4>
                  <ul className="space-y-2">
                    {departments.map(d => (
                      <li key={d.id} className="p-4 bg-slate-50 rounded-xl flex justify-between items-center group">
                        <span className="font-medium">{d.name}</span>
                        <span className="text-xs text-slate-400 group-hover:text-blue-500 cursor-pointer">Editar</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-600 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    Centros de Custo
                  </h4>
                  <ul className="space-y-2">
                    {costCenters.map(c => (
                      <li key={c.id} className="p-4 bg-slate-50 rounded-xl flex justify-between items-center group">
                        <div>
                          <span className="font-medium block">{c.name}</span>
                          <span className="text-xs text-slate-400 font-mono">{c.code}</span>
                        </div>
                        <span className="text-xs text-slate-400 group-hover:text-blue-500 cursor-pointer">Editar</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {isFormOpen && (
          <AssetForm 
            asset={editingAsset}
            departments={departments}
            costCenters={costCenters}
            onSave={handleSaveAsset}
            onCancel={() => setIsFormOpen(false)}
          />
        )}
      </main>

      {/* Mobile Navigation */}
      <nav className="lg:hidden fixed bottom-6 left-6 right-6 h-20 bg-white/80 backdrop-blur-md shadow-2xl rounded-3xl border border-white/20 flex items-center justify-around px-4 z-50">
        <button onClick={() => setActiveView(View.DASHBOARD)} className={`p-3 rounded-2xl transition-all ${activeView === View.DASHBOARD ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><Icons.Dashboard /></button>
        <button onClick={() => setActiveView(View.ASSETS)} className={`p-3 rounded-2xl transition-all ${activeView === View.ASSETS ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><Icons.Assets /></button>
        <button onClick={() => setIsFormOpen(true)} className="w-14 h-14 bg-slate-900 rounded-full flex items-center justify-center text-white -mt-16 shadow-2xl shadow-slate-300 border-4 border-slate-50 active:scale-90 transition-transform"><Icons.Plus /></button>
        <button onClick={() => setActiveView(View.MOVEMENTS)} className={`p-3 rounded-2xl transition-all ${activeView === View.MOVEMENTS ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><Icons.Movements /></button>
        <button onClick={() => setActiveView(View.SETTINGS)} className={`p-3 rounded-2xl transition-all ${activeView === View.SETTINGS ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><Icons.Settings /></button>
      </nav>
    </div>
  );
};

export default App;
