
import React, { useState } from 'react';
import { Asset, AssetStatus, Department, CostCenter } from '../types';
import { CATEGORIES } from '../constants';

interface AssetFormProps {
  asset?: Partial<Asset>;
  departments: Department[];
  costCenters: CostCenter[];
  onSave: (asset: Asset) => void;
  onCancel: () => void;
}

export const AssetForm: React.FC<AssetFormProps> = ({ asset, departments, costCenters, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Partial<Asset>>(asset || {
    name: '',
    category: CATEGORIES[0],
    status: AssetStatus.STOCK,
    departmentId: departments[0]?.id || '',
    costCenterId: costCenters[0]?.id || '',
    value: 0,
    serialNumber: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    nfeKey: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, id: asset?.id || Date.now().toString() } as Asset);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <form 
        onSubmit={handleSubmit}
        className="bg-white rounded-[2rem] w-full max-w-2xl overflow-hidden shadow-2xl animate-scaleUp"
      >
        <div className="p-8 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-xl font-bold text-slate-800">
            {asset?.id ? 'Editar Ativo' : 'Novo Cadastro de Ativo'}
          </h3>
          <button type="button" onClick={onCancel} className="text-slate-400 hover:text-slate-600">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l18 18" />
            </svg>
          </button>
        </div>
        
        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6 max-h-[70vh] overflow-y-auto">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Nome do Ativo</label>
            <input 
              required
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Notebook Dell XPS 15"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Número de Série</label>
            <input 
              required
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              value={formData.serialNumber}
              onChange={e => setFormData({ ...formData, serialNumber: e.target.value })}
              placeholder="Ex: ABC-123-XYZ"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Categoria</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none bg-white"
              value={formData.category}
              onChange={e => setFormData({ ...formData, category: e.target.value })}
            >
              {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Status Operacional</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none bg-white"
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value as AssetStatus })}
            >
              {Object.values(AssetStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Departamento</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none bg-white"
              value={formData.departmentId}
              onChange={e => setFormData({ ...formData, departmentId: e.target.value })}
            >
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Centro de Custo</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none bg-white"
              value={formData.costCenterId}
              onChange={e => setFormData({ ...formData, costCenterId: e.target.value })}
            >
              {costCenters.map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Data de Compra</label>
            <input 
              type="date"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.purchaseDate}
              onChange={e => setFormData({ ...formData, purchaseDate: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Valor de Aquisição</label>
            <input 
              type="number"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.value}
              onChange={e => setFormData({ ...formData, value: Number(e.target.value) })}
            />
          </div>

          <div className="col-span-1 md:col-span-2 space-y-2">
            <label className="text-sm font-semibold text-slate-700">Chave da NF-e</label>
            <input 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
              value={formData.nfeKey}
              onChange={e => setFormData({ ...formData, nfeKey: e.target.value })}
              placeholder="44 dígitos da chave eletrônica"
              maxLength={44}
            />
          </div>
        </div>

        <div className="p-8 bg-slate-50 flex gap-4 justify-end">
          <button 
            type="button" 
            onClick={onCancel}
            className="px-6 py-3 rounded-xl font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Cancelar
          </button>
          <button 
            type="submit"
            className="px-8 py-3 rounded-xl font-bold bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all active:scale-95"
          >
            Salvar Ativo
          </button>
        </div>
      </form>
    </div>
  );
};
