
import React, { useState } from 'react';
import { Asset, AssetStatus } from '../types';

interface AssetListProps {
  assets: Asset[];
  departments: any[];
  costCenters: any[];
  onEdit: (asset: Asset) => void;
}

const statusColors: Record<AssetStatus, string> = {
  [AssetStatus.IN_OPERATION]: 'bg-emerald-100 text-emerald-700',
  [AssetStatus.REPAIR]: 'bg-red-100 text-red-700',
  [AssetStatus.STOCK]: 'bg-amber-100 text-amber-700',
  [AssetStatus.DISUSE]: 'bg-slate-200 text-slate-700',
  [AssetStatus.REPLACEMENT]: 'bg-blue-100 text-blue-700',
};

export const AssetList: React.FC<AssetListProps> = ({ assets, departments, costCenters, onEdit }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredAssets = assets.filter(asset => 
    asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    asset.serialNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="relative group">
        <input 
          type="text" 
          placeholder="Buscar por nome ou número de série..."
          className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 shadow-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all group-hover:border-slate-300"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <svg className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-slideUp">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Ativo</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Categoria</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Depto / C. Custo</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Valor</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredAssets.length > 0 ? filteredAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium text-slate-900">{asset.name}</div>
                    <div className="text-xs text-slate-500">SN: {asset.serialNumber}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{asset.category}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[asset.status]}`}>
                      {asset.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="text-slate-800">{departments.find(d => d.id === asset.departmentId)?.name || 'N/A'}</div>
                    <div className="text-xs text-slate-500">{costCenters.find(c => c.id === asset.costCenterId)?.name || 'N/A'}</div>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-slate-900">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(asset.value)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => onEdit(asset)}
                      className="text-blue-600 hover:text-blue-800 text-sm font-semibold transition-colors"
                    >
                      Detalhes
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500 italic">
                    Nenhum ativo encontrado para esta busca.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
