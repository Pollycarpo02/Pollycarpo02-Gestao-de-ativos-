
import React from 'react';
import { Asset, AssetStatus } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface DashboardProps {
  assets: Asset[];
}

const COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6'];

export const Dashboard: React.FC<DashboardProps> = ({ assets }) => {
  const statusCounts = Object.values(AssetStatus).map(status => ({
    name: status,
    value: assets.filter(a => a.status === status).length
  }));

  const categoryCounts = Array.from(new Set(assets.map(a => a.category))).map(cat => ({
    name: cat,
    value: assets.filter(a => a.category === cat).length
  }));

  const totalValue = assets.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <p className="text-slate-500 text-sm font-medium">Total de Ativos</p>
          <h3 className="text-3xl font-bold mt-1 text-slate-800">{assets.length}</h3>
          <div className="mt-2 text-xs text-blue-600 font-semibold bg-blue-50 py-1 px-2 rounded-full inline-block">
            +12% este mês
          </div>
        </div>
        <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <p className="text-slate-500 text-sm font-medium">Valor Total</p>
          <h3 className="text-3xl font-bold mt-1 text-slate-800">
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalValue)}
          </h3>
          <div className="mt-2 text-xs text-emerald-600 font-semibold bg-emerald-50 py-1 px-2 rounded-full inline-block">
            Patrimônio Ativo
          </div>
        </div>
        <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <p className="text-slate-500 text-sm font-medium">Em Reparo</p>
          <h3 className="text-3xl font-bold mt-1 text-red-500">
            {assets.filter(a => a.status === AssetStatus.REPAIR).length}
          </h3>
          <div className="mt-2 text-xs text-red-600 font-semibold bg-red-50 py-1 px-2 rounded-full inline-block">
            Requer Atenção
          </div>
        </div>
        <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <p className="text-slate-500 text-sm font-medium">Em Estoque</p>
          <h3 className="text-3xl font-bold mt-1 text-amber-500">
            {assets.filter(a => a.status === AssetStatus.STOCK).length}
          </h3>
          <div className="mt-2 text-xs text-amber-600 font-semibold bg-amber-50 py-1 px-2 rounded-full inline-block">
            Pronto p/ Uso
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="p-8 bg-white rounded-3xl shadow-sm border border-slate-100">
          <h4 className="text-lg font-semibold mb-6 text-slate-800">Status dos Ativos</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusCounts}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusCounts.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-8 bg-white rounded-3xl shadow-sm border border-slate-100">
          <h4 className="text-lg font-semibold mb-6 text-slate-800">Distribuição por Categoria</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryCounts}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
