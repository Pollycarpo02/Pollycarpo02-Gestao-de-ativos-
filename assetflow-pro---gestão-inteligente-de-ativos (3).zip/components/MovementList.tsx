
import React from 'react';
import { Movement } from '../types';

interface MovementListProps {
  movements: Movement[];
  assets: any[];
}

export const MovementList: React.FC<MovementListProps> = ({ movements, assets }) => {
  if (movements.length === 0) {
    return (
      <div className="bg-white p-12 rounded-3xl text-center border border-slate-100 animate-fadeIn">
        <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
           <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-slate-800">Nenhuma movimentação registrada</h3>
        <p className="text-slate-500 mt-2">As alterações de status e transferências aparecerão aqui.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-slideUp">
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Data</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Ativo</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Tipo</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Descrição</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">NF-e</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {movements.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 text-sm text-slate-600">
                  {new Date(m.date).toLocaleDateString('pt-BR')}
                </td>
                <td className="px-6 py-4 font-medium text-slate-900">
                  {assets.find(a => a.id === m.assetId)?.name || 'Ativo Removido'}
                </td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    m.type === 'Entrada' ? 'bg-emerald-100 text-emerald-700' :
                    m.type === 'Saída' ? 'bg-red-100 text-red-700' :
                    m.type === 'Manutenção' ? 'bg-amber-100 text-amber-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {m.type}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{m.description}</td>
                <td className="px-6 py-4 text-xs font-mono text-slate-400">
                  {m.nfeKey || '---'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
