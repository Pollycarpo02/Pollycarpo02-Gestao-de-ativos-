
import { Asset, Movement, Department, CostCenter, AssetStatus } from '../types';

const KEYS = {
  ASSETS: 'assetflow_assets',
  MOVEMENTS: 'assetflow_movements',
  DEPARTMENTS: 'assetflow_departments',
  COST_CENTERS: 'assetflow_cost_centers'
};

const initialDepartments: Department[] = [
  { id: '1', name: 'Tecnologia' },
  { id: '2', name: 'RH' },
  { id: '3', name: 'Operações' }
];

const initialCostCenters: CostCenter[] = [
  { id: '1', code: 'CC-001', name: 'Administração Central' },
  { id: '2', code: 'CC-002', name: 'Produção Fábrica' }
];

const initialAssets: Asset[] = [
  {
    id: '1',
    name: 'MacBook Pro M3',
    category: 'Hardware',
    status: AssetStatus.IN_OPERATION,
    departmentId: '1',
    costCenterId: '1',
    purchaseDate: '2024-01-15',
    value: 15000,
    serialNumber: 'SN12345678',
    nfeKey: '35240112345678901234567890123456789012345678'
  },
  {
    id: '2',
    name: 'Servidor Dell PowerEdge',
    category: 'Hardware',
    status: AssetStatus.REPAIR,
    departmentId: '1',
    costCenterId: '2',
    purchaseDate: '2023-11-20',
    value: 45000,
    serialNumber: 'DELL-998877',
    nfeKey: '35240112345678901234567890123456789012345679'
  },
  {
    id: '3',
    name: 'Cadeira Ergonômica Pro',
    category: 'Mobiliário',
    status: AssetStatus.STOCK,
    departmentId: '2',
    costCenterId: '1',
    purchaseDate: '2024-02-10',
    value: 2500,
    serialNumber: 'CH-2024-01',
    nfeKey: ''
  }
];

export const storage = {
  getAssets: (): Asset[] => {
    const data = localStorage.getItem(KEYS.ASSETS);
    if (!data) {
      localStorage.setItem(KEYS.ASSETS, JSON.stringify(initialAssets));
      return initialAssets;
    }
    return JSON.parse(data);
  },
  saveAsset: (asset: Asset) => {
    const assets = storage.getAssets();
    const index = assets.findIndex(a => a.id === asset.id);
    if (index > -1) assets[index] = asset;
    else assets.push(asset);
    localStorage.setItem(KEYS.ASSETS, JSON.stringify(assets));
  },
  getDepartments: (): Department[] => {
    const data = localStorage.getItem(KEYS.DEPARTMENTS);
    if (!data) {
      localStorage.setItem(KEYS.DEPARTMENTS, JSON.stringify(initialDepartments));
      return initialDepartments;
    }
    return JSON.parse(data);
  },
  getCostCenters: (): CostCenter[] => {
    const data = localStorage.getItem(KEYS.COST_CENTERS);
    if (!data) {
      localStorage.setItem(KEYS.COST_CENTERS, JSON.stringify(initialCostCenters));
      return initialCostCenters;
    }
    return JSON.parse(data);
  },
  getMovements: (): Movement[] => {
    const data = localStorage.getItem(KEYS.MOVEMENTS);
    return data ? JSON.parse(data) : [];
  },
  addMovement: (movement: Movement) => {
    const movements = storage.getMovements();
    movements.push(movement);
    localStorage.setItem(KEYS.MOVEMENTS, JSON.stringify(movements));
  }
};
