
export enum AssetStatus {
  IN_OPERATION = 'Em Operação',
  REPAIR = 'Em Reparo',
  STOCK = 'Em Estoque',
  DISUSE = 'Desuso',
  REPLACEMENT = 'Substituição'
}

export interface Department {
  id: string;
  name: string;
}

export interface CostCenter {
  id: string;
  code: string;
  name: string;
}

export interface Asset {
  id: string;
  name: string;
  category: string;
  status: AssetStatus;
  departmentId: string;
  costCenterId: string;
  purchaseDate: string;
  value: number;
  nfeKey?: string;
  serialNumber: string;
}

export interface Movement {
  id: string;
  assetId: string;
  type: 'Entrada' | 'Saída' | 'Transferência' | 'Manutenção';
  date: string;
  description: string;
  nfeKey?: string;
}
